#version 330
#extension GL_ARB_separate_shader_objects : require

uniform sampler2D InSampler;

layout(location = 0) in vec2 texCoord;
layout(location = 0) out vec4 fragColor;

const float COLOR_LIFT     = 0.1; //= 0.04;
const float GAMMA_INV      = 1.0 / 1.25;
const float BASE_DESAT     = 0.78;
const vec3  TINT_COLOR     = vec3(1.05, 1.01, 0.94);
const float SHADOW_CRUSH   = 0.03;
const float HIGHLIGHT_CLIP = 0.92;
const float CONTRAST       = 1.25;
const float EXPOSURE       = 0.85;
const vec3  SATURATION     = vec3(1.05, 1.10, 1.03);
const vec3  QUANT_STEPS    = vec3(15.0, 31.0, 15.0);

void main(){
    vec3 color = texture(InSampler, texCoord).rgb;

    color += COLOR_LIFT;
    color = pow(color, vec3(GAMMA_INV));

    float luma = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(vec3(luma), color, BASE_DESAT);

    color *= TINT_COLOR;
    color = max(color - SHADOW_CRUSH, 0.0);
    color = min(color, vec3(HIGHLIGHT_CLIP));

    color = ((color - 0.5) * CONTRAST) + 0.5;
    color *= EXPOSURE;

    color = mix(vec3(luma), color, SATURATION);

    color = floor(color * QUANT_STEPS) / QUANT_STEPS;

    fragColor = vec4(color, 1.0);
}
