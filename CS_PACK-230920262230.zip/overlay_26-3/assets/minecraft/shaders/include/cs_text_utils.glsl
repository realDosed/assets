vec3 cs_txt_color_slots(bool is_big, vec3 color) {
    if (!is_big) {
        if (util_eq(color, util_color_to_vec(228.0, 247.0, 124.0))) return util_color_to_vec(170.0, 170.0, 170.0); // gray
        if (util_eq(color, util_color_to_vec(228.0, 250.0, 124.0))) return util_color_to_vec(255.0,  85.0,  85.0); // red
        if (util_eq(color, util_color_to_vec(228.0, 255.0, 124.0))) return util_color_to_vec( 85.0, 255.0,  85.0); // lime
        if (util_eq(color, util_color_to_vec(228.0, 242.0, 124.0))) return util_color_to_vec( 85.0, 255.0, 255.0); // aqua
        if (util_eq(color, util_color_to_vec(228.0, 238.0, 124.0))) return util_color_to_vec(255.0, 170.0,   0.0); // gold
        if (util_eq(color, util_color_to_vec(228.0, 232.0, 124.0))) return util_color_to_vec(255.0,  85.0, 255.0); // purple
        return vec3(1.0);
    } else {
        if (util_eq(color, util_color_to_vec(228.0, 247.0, 122.0))) return util_color_to_vec(170.0, 170.0, 170.0); // gray
        if (util_eq(color, util_color_to_vec(228.0, 250.0, 122.0))) return util_color_to_vec(255.0,  85.0,  85.0); // red
        if (util_eq(color, util_color_to_vec(228.0, 255.0, 122.0))) return util_color_to_vec( 85.0, 255.0,  85.0); // lime
        if (util_eq(color, util_color_to_vec(228.0, 242.0, 122.0))) return util_color_to_vec( 85.0, 255.0, 255.0); // aqua
        if (util_eq(color, util_color_to_vec(228.0, 238.0, 122.0))) return util_color_to_vec(255.0, 170.0,   0.0); // gold
        if (util_eq(color, util_color_to_vec(228.0, 232.0, 122.0))) return util_color_to_vec(255.0,  85.0, 255.0); // purple
        return vec3(1.0);
    }
}
vec3 cs_txt_color_slots(bool is_big, bool shadow, vec3 color) {
    if (!is_big) {
        if (!shadow) {
            if (util_eq(color, util_color_to_vec(228.0, 247.0, 126.0))) return util_color_to_vec(170.0, 170.0, 170.0); // gray
            if (util_eq(color, util_color_to_vec(228.0, 250.0, 126.0))) return util_color_to_vec(255.0,  85.0,  85.0); // red
            if (util_eq(color, util_color_to_vec(228.0, 255.0, 126.0))) return util_color_to_vec( 85.0, 255.0,  85.0); // lime
            if (util_eq(color, util_color_to_vec(228.0, 242.0, 126.0))) return util_color_to_vec( 85.0, 255.0, 255.0); // aqua
            if (util_eq(color, util_color_to_vec(228.0, 238.0, 126.0))) return util_color_to_vec(255.0, 170.0,   0.0); // gold
            if (util_eq(color, util_color_to_vec(228.0, 232.0, 126.0))) return util_color_to_vec(255.0,  85.0, 255.0); // purple
            return vec3(1.0);
        } else {
            if (util_eq(color, util_color_to_vec( 57.0,  61.0,  31.0))) return util_color_to_vec( 42.0,  42.0,  42.0); // gray
            if (util_eq(color, util_color_to_vec( 57.0,  62.0,  31.0))) return util_color_to_vec( 63.0,  21.0,  21.0); // red
            if (util_eq(color, util_color_to_vec( 57.0,  63.0,  31.0))) return util_color_to_vec( 21.0,  63.0,  21.0); // lime
            if (util_eq(color, util_color_to_vec( 57.0,  60.0,  31.0))) return util_color_to_vec( 21.0,  63.0,  63.0); // aqua
            if (util_eq(color, util_color_to_vec( 57.0,  59.0,  31.0))) return util_color_to_vec( 63.0,  42.0,   0.0); // gold
            if (util_eq(color, util_color_to_vec( 57.0,  58.0,  31.0))) return util_color_to_vec( 63.0,  21.0,  63.0); // purple
            return vec3(0.0);
        }
    } else {
        if (!shadow) {
            if (util_eq(color, util_color_to_vec(228.0, 247.0, 128.0))) return util_color_to_vec(170.0, 170.0, 170.0); // gray
            if (util_eq(color, util_color_to_vec(228.0, 250.0, 128.0))) return util_color_to_vec(255.0,  85.0,  85.0); // red
            if (util_eq(color, util_color_to_vec(228.0, 255.0, 128.0))) return util_color_to_vec( 85.0, 255.0,  85.0); // lime
            if (util_eq(color, util_color_to_vec(228.0, 242.0, 128.0))) return util_color_to_vec( 85.0, 255.0, 255.0); // aqua
            if (util_eq(color, util_color_to_vec(228.0, 238.0, 128.0))) return util_color_to_vec(255.0, 170.0,   0.0); // gold
            if (util_eq(color, util_color_to_vec(228.0, 232.0, 128.0))) return util_color_to_vec(255.0,  85.0, 255.0); // purple
            return vec3(1.0);
        } else {
            if (util_eq(color, util_color_to_vec( 57.0,  61.0,  32.0))) return util_color_to_vec( 42.0,  42.0,  42.0); // gray
            if (util_eq(color, util_color_to_vec( 57.0,  62.0,  32.0))) return util_color_to_vec( 63.0,  21.0,  21.0); // red
            if (util_eq(color, util_color_to_vec( 57.0,  63.0,  32.0))) return util_color_to_vec( 21.0,  63.0,  21.0); // lime
            if (util_eq(color, util_color_to_vec( 57.0,  60.0,  32.0))) return util_color_to_vec( 21.0,  63.0,  63.0); // aqua
            if (util_eq(color, util_color_to_vec( 57.0,  59.0,  32.0))) return util_color_to_vec( 63.0,  42.0,   0.0); // gold
            if (util_eq(color, util_color_to_vec( 57.0,  58.0,  32.0))) return util_color_to_vec( 63.0,  21.0,  63.0); // purple
            return vec3(0.0);
        }
    }
}
vec3 cs_txt_color_action(bool is_dark, bool shadow, vec3 color) {
    if (!is_dark) {
        if (!shadow) {
            if (util_eq(color, util_color_to_vec(255.0, 168.0,   0.0))) return util_color_to_vec(170.0, 170.0, 170.0); // gray
            if (util_eq(color, util_color_to_vec(255.0, 164.0,   0.0))) return util_color_to_vec(255.0,  85.0,  85.0); // red
            if (util_eq(color, util_color_to_vec(255.0, 162.0,   0.0))) return util_color_to_vec( 85.0, 255.0,  85.0); // lime
            if (util_eq(color, util_color_to_vec(255.0, 158.0,   0.0))) return util_color_to_vec( 85.0, 255.0, 255.0); // aqua
            if (util_eq(color, util_color_to_vec(255.0, 152.0,   0.0))) return util_color_to_vec(255.0, 170.0,   0.0); // gold
            if (util_eq(color, util_color_to_vec(255.0, 148.0,   0.0))) return util_color_to_vec(255.0,  85.0, 255.0); // purple
            return vec3(1.0);
        } else {
            if (util_eq(color, util_color_to_vec( 63.0,  42.0,   0.0))) return util_color_to_vec( 42.0,  42.0,  42.0); // gray
            if (util_eq(color, util_color_to_vec( 63.0,  41.0,   0.0))) return util_color_to_vec( 63.0,  21.0,  21.0); // red
            if (util_eq(color, util_color_to_vec( 63.0,  40.0,   0.0))) return util_color_to_vec( 21.0,  63.0,  21.0); // lime
            if (util_eq(color, util_color_to_vec( 63.0,  39.0,   0.0))) return util_color_to_vec( 21.0,  63.0,  63.0); // aqua
            if (util_eq(color, util_color_to_vec( 63.0,  38.0,   0.0))) return util_color_to_vec( 63.0,  42.0,   0.0); // gold
            if (util_eq(color, util_color_to_vec( 63.0,  37.0,   0.0))) return util_color_to_vec( 63.0,  21.0,  63.0); // purple
            return vec3(0.0);
        }
    } else {
        if (!shadow) {
            if (util_eq(color, util_color_to_vec(128.0,  88.0,   0.0))) return util_color_to_vec( 85.0,  85.0,  85.0); // gray
            if (util_eq(color, util_color_to_vec(128.0,  84.0,   0.0))) return util_color_to_vec(127.0,  42.0,  42.0); // red
            if (util_eq(color, util_color_to_vec(128.0,  81.0,   0.0))) return util_color_to_vec( 42.0, 127.0,  42.0); // lime
            if (util_eq(color, util_color_to_vec(128.0,  78.0,   0.0))) return util_color_to_vec( 42.0, 127.0, 127.0); // aqua
            if (util_eq(color, util_color_to_vec(128.0,  72.0,   0.0))) return util_color_to_vec(127.0,  85.0,   0.0); // gold
            if (util_eq(color, util_color_to_vec(128.0,  68.0,   0.0))) return util_color_to_vec(127.0,  42.0, 127.0); // purple
            return vec3(1.0);
        } else {
            if (util_eq(color, util_color_to_vec( 32.0,  22.0,   0.0))) return util_color_to_vec( 21.0,  21.0,  21.0); // gray
            if (util_eq(color, util_color_to_vec( 32.0,  21.0,   0.0))) return util_color_to_vec( 31.0,  10.0,  10.0); // red
            if (util_eq(color, util_color_to_vec( 32.0,  20.0,   0.0))) return util_color_to_vec( 10.0,  31.0,  10.0); // lime
            if (util_eq(color, util_color_to_vec( 32.0,  19.0,   0.0))) return util_color_to_vec( 10.0,  31.0,  31.0); // aqua
            if (util_eq(color, util_color_to_vec( 32.0,  18.0,   0.0))) return util_color_to_vec( 31.0,  21.0,   0.0); // gold
            if (util_eq(color, util_color_to_vec( 32.0,  17.0,   0.0))) return util_color_to_vec( 31.0,  10.0,  31.0); // purple
            return vec3(0.0);
        }
    }
}
vec4 cs_txt_move_crosshair(mat4 projmat, mat4 modelviewmat, vec4 pos, vec2 screen_size) {
    int scale = util_gui_scale(projmat, screen_size);
    vec2 pixel = util_gui_pixel(projmat);

    pos     = projmat * modelviewmat * pos;
    pos.xy *= 1.0 / scale;
    pos.x  -= (pixel.x * -0.5) * (4.0 / scale);
    pos.y  -= (pixel.y * 29.5) * (4.0 / scale);

    return pos;
}
vec4 cs_txt_move_action(bool shadow, mat4 projmat, mat4 modelviewmat, vec4 pos, vec2 screen_size) {
    int scale = util_gui_scale(projmat, screen_size);

    pos.y  += screen_size.y / 3.2;
    pos.y  += 16.0;
    pos.z  += 1.0;
    pos     = projmat * modelviewmat * pos;
    pos.xy *= 1.5 / scale;

    if (shadow) {
        const vec2[4] corners_1 = vec2[4](vec2(1,  1), vec2(1, 0), vec2(0, 0), vec2(0,  1));
        const vec2[4] corners_2 = vec2[4](vec2(0,  0), vec2(0, 1), vec2(1, 1), vec2(1,  0));
        vec2 corner_1 = corners_1[gl_VertexIndex % 4];
        vec2 corner_2 = corners_2[gl_VertexIndex % 4];

        vec2 pixel = util_gui_pixel(projmat) * (12.0 / scale);

        pos.xy -= corner_1 * pixel * 1.5;
        pos.xy -= corner_2 * pixel * 0.5;
    }

    return pos;
}
vec4 cs_full_quad(mat4 projmat, mat4 modelviewmat, vec4 pos, float z_shift) {
    const vec2[4] corners = vec2[4](vec2(-1, 1), vec2(-1, -1), vec2(1, -1), vec2(1, 1));
    vec2 corner = corners[gl_VertexIndex % 4];

    pos     = projmat * modelviewmat * pos;
    pos.xy  = corner;
    pos.z  += z_shift;

    return pos;
}
