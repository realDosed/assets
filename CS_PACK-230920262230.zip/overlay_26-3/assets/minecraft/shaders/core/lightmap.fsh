#version 330
#extension GL_ARB_separate_shader_objects : require

layout(std140) uniform LightmapInfo {
    float SkyFactor;
    float BlockFactor;
    float NightVisionFactor;
    float DarknessScale;
    float BossOverlayWorldDarkeningFactor;
    float BrightnessFactor;
    vec3 BlockLightTint;
    vec3 SkyLightColor;
    vec3 AmbientColor;
    vec3 NightVisionColor;
} lightmapInfo;

layout(location = 0) in vec2 texCoord;

layout(location = 0) out vec4 fragColor;

// CS_PACK - Edited
float get_brightness(float light_level, float ambient) {
    float darkness = 1.0 - light_level;
    return (1.0 - darkness) / (darkness * 3.0 + 1.0) * (1.0 - ambient) + ambient;
}

// CS_PACK - Edited
vec3 notGamma(vec3 color) {
    float maxComponent = max(max(color.x, color.y), color.z);
    float maxInverted = 1.0f - maxComponent;
    float maxScaled = 1.0f - maxInverted * maxInverted * maxInverted;
    return color * (maxScaled / maxComponent);
}

void main() {
    float block_level = floor(texCoord.x * 16) / 15;
    float sky_level = floor(texCoord.y * 16) / 15;

    // CS_PACK - Edited
    float light_level = max(block_level, sky_level);
    light_level = clamp(light_level, 0.0, 1.0);

    float ambient = (lightmapInfo.AmbientColor.r + lightmapInfo.AmbientColor.g + lightmapInfo.AmbientColor.b) / 3.0;
    ambient = clamp(ambient, 0.05, 1.0);

    float brightness = get_brightness(light_level, ambient);
    vec3 color = vec3(brightness);

    color = mix(color, color * max(light_level, 0.4), lightmapInfo.BossOverlayWorldDarkeningFactor);
    color -= vec3(lightmapInfo.DarknessScale);
    color = clamp(color, 0.0, 1.0);

    vec3 gammaColor = notGamma(color);
    color = mix(color, gammaColor, 0.25);

    if (lightmapInfo.NightVisionFactor > 0.0) {
        color = mix(color, vec3(0.65, 1.0, 0.65), lightmapInfo.NightVisionFactor);
    }
    if (lightmapInfo.BrightnessFactor > 1.0) {
        color *= lightmapInfo.BrightnessFactor;
    }

    color = clamp(color, 0.0, 1.0);
    fragColor = vec4(color, 1.0);
}
