#version 330
#extension GL_ARB_separate_shader_objects : require

// Can't moj_import in things used during startup, when resource packs don't exist.
// This is a copy of dynamicimports.glsl and projection.glsl
layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    mat4 TextureMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;

layout(location = 0) out vec4 vertexColor;

// CS_PACK
bool util_eq(vec3 a, vec3 b) {
    return length(a - b) < 0.002;
}
bool util_eq(vec4 a, vec4 b) {
    return length(a - b) < 0.002;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;

    // CS_PACK
    // disable cooldown, chat bg and simillar stuff
    if (
        util_eq(Color, vec4(1.0, 1.0, 1.0, 0.5)) ||
        (util_eq(Color.rgb, vec3(0.0)) && Color.a <= 0.502)
    ) {
        vertexColor = vec4(0.0);
    }
}
