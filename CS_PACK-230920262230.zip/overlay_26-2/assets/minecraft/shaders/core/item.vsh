#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#moj_import <minecraft:globals.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;

out vec2 texCoord0;

// CS_PACK
#moj_import <cs_utils.glsl>

// OBJMC
out vec3 Pos;
out vec2 texCoord2;
out float transition;
flat out int isCustom;
flat out int isGUI;
flat out int isHand;
flat out int noshadow;
#moj_import <objmc_tools.glsl>

void main() {
    Pos = Position;
    texCoord0 = UV0;
    texCoord2 = UV2;

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);

    // CS_PACK
    #define VERTEX
    #moj_import <cs_item.glsl>
    // OBJMC
    #moj_import <objmc_main.glsl>

    sphericalVertexDistance = fog_spherical_distance(Pos);
    cylindricalVertexDistance = fog_cylindrical_distance(Pos);

    gl_Position = ProjMat * ModelViewMat * vec4(Pos, 1.0);
}
