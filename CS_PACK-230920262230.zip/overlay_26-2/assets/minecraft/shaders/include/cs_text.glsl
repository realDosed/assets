#if !defined(IS_GRAYSCALE) && defined(VERTEX)
// normal font vertex
is_crosshair = 0;
// solid colors
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 20.0))       // full quad white
) {
    vertexColor.rgb = vec3(1.0);
    gl_Position = cs_full_quad(ProjMat, ModelViewMat, Pos, -0.1);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(75.0, 80.0, 20.0))       // full quad black
) {
    is_crosshair = 1;
    vertexColor.rgb = vec3(0.0);
    gl_Position = cs_full_quad(ProjMat, ModelViewMat, Pos, 0.0);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(80.0, 80.0, 20.0))       // full quad red
) {
    vertexColor = vec4(1.0, 0.0, 0.0, clamp(vertexColor.a, 0.0, 0.12));
    gl_Position = cs_full_quad(ProjMat, ModelViewMat, Pos, 0.0);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(85.0, 80.0, 20.0))       // full quad white transp
) {
    vertexColor = vec4(vec3(1.0), clamp(vertexColor.a, 0.0, 0.12));
    gl_Position = cs_full_quad(ProjMat, ModelViewMat, Pos, 0.0);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 40.0))       // crosshair gray
) {
    vertexColor.rgb = util_color_to_vec(170.0, 170.0, 170.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 42.0))       // crosshair red
) {
    vertexColor.rgb = util_color_to_vec(255.0, 85.0, 85.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 44.0))       // crosshair lime
) {
    vertexColor.rgb = util_color_to_vec(85.0, 255.0, 85.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 46.0))       // crosshair aqua
) {
    vertexColor.rgb = util_color_to_vec(85.0, 255.0, 255.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 48.0))       // crosshair gold
) {
    vertexColor.rgb = util_color_to_vec(255.0, 170.0, 0.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 50.0))       // crosshair purple
) {
    vertexColor.rgb = util_color_to_vec(255.0, 85.0, 255.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(228.0, 247.0, 124.0)) || // slots normal
    util_eq(Color.rgb, util_color_to_vec(228.0, 250.0, 124.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 255.0, 124.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 242.0, 124.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 238.0, 124.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 232.0, 124.0))
) {
    vertexColor.rgb = cs_txt_color_slots(false, Color.rgb);

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 4.0 / scale;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 0.5672;
            Pos.y += ScreenSize.y / 28.0 - 44.0 / scale;
            break;
        case 2:
            Pos.x -= ScreenSize.x / 2.622;
            Pos.y += ScreenSize.y / 56.0 - 44.0 / scale;
            break;
        case 3:
            Pos.x -= ScreenSize.x / 6.98;
            Pos.y += ScreenSize.y / 84.0 - 44.0 / scale;
            break;
        case 4:
            Pos.x -= ScreenSize.x / 15.2;
            Pos.y += ScreenSize.y / 112.0 - 44.0 / scale;
            break;
    }

    Pos.x += 29.0;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(228.0, 247.0, 122.0)) || // slots big
    util_eq(Color.rgb, util_color_to_vec(228.0, 250.0, 122.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 255.0, 122.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 242.0, 122.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 238.0, 122.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 232.0, 122.0))
) {
    vertexColor.rgb = cs_txt_color_slots(true, Color.rgb);

    float f = 1.5;

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 4.0 / scale * f;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 0.5672 * f + (112.0 / scale);
            Pos.y += ScreenSize.y / 28.0 - (50.0 / scale) * f;
            break;
        case 2:
            Pos.x -= ScreenSize.x / 2.622 * f + (113.0 / scale);
            Pos.y += ScreenSize.y / 56.0 - (50.0 / scale) * f;
            break;
        case 3:
            Pos.x -= ScreenSize.x / 6.98 * f + (112.0 / scale);
            Pos.y += ScreenSize.y / 84.0 - (50.0 / scale) * f;
            break;
        case 4:
            Pos.x -= ScreenSize.x / 15.2 * f + (112.0 / scale);
            Pos.y += ScreenSize.y / 112.0 - (50.0 / scale) * f;
            break;
    }

    Pos.x += 50.0;
    Pos.y += 4.5;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(255.0, 255.0, 90.0))     // item names + inv char
) {
    vertexColor = vec4(0.0);
}
if (
    util_eq(Color.rgb, util_color_to_vec(250.0, 170.0, 0.0)) ||   // smaller title
    util_eq(Color.rgb, util_color_to_vec(250.0, 85.0, 85.0))
) {
    Pos     = ProjMat * ModelViewMat * Pos;
    Pos.xy *= 0.75;
    Pos.y  += 0.05;
    gl_Position = Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(90.0, 110.0, 50.0))      // action bar bg
) {
    vertexColor.rgb = vec3(1.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
// shadow colors
if (
    util_eq(Color.rgb, util_color_to_vec(17.0, 20.0,  5.0)) ||    // full quad white
    util_eq(Color.rgb, util_color_to_vec(18.0, 20.0,  5.0)) ||    // full quad black
    util_eq(Color.rgb, util_color_to_vec(20.0, 20.0,  5.0)) ||    // full quad red
    util_eq(Color.rgb, util_color_to_vec(21.0, 20.0,  5.0)) ||    // full quad white transp
    util_eq(Color.rgb, util_color_to_vec(17.0, 20.0, 10.0)) ||    // crosshair gray + red
    util_eq(Color.rgb, util_color_to_vec(17.0, 20.0, 11.0)) ||    // crosshair lime + aqua
    util_eq(Color.rgb, util_color_to_vec(17.0, 20.0, 12.0)) ||    // crosshair gold + purple
    util_eq(Color.rgb, util_color_to_vec(57.0, 61.0, 31.0)) ||    // slots normal gray
    util_eq(Color.rgb, util_color_to_vec(57.0, 62.0, 31.0)) ||    // slots normal red
    util_eq(Color.rgb, util_color_to_vec(57.0, 63.0, 31.0)) ||    // slots normal lime
    util_eq(Color.rgb, util_color_to_vec(57.0, 60.0, 31.0)) ||    // slots normal aqua
    util_eq(Color.rgb, util_color_to_vec(57.0, 59.0, 31.0)) ||    // slots normal gold
    util_eq(Color.rgb, util_color_to_vec(57.0, 58.0, 31.0)) ||    // slots normal purple
    util_eq(Color.rgb, util_color_to_vec(57.0, 61.0, 30.0)) ||    // slots big gray
    util_eq(Color.rgb, util_color_to_vec(57.0, 62.0, 30.0)) ||    // slots big red
    util_eq(Color.rgb, util_color_to_vec(57.0, 63.0, 30.0)) ||    // slots big lime
    util_eq(Color.rgb, util_color_to_vec(57.0, 60.0, 30.0)) ||    // slots big aqua
    util_eq(Color.rgb, util_color_to_vec(57.0, 59.0, 30.0)) ||    // slots big gold
    util_eq(Color.rgb, util_color_to_vec(57.0, 58.0, 30.0)) ||    // slots big purple
    util_eq(Color.rgb, util_color_to_vec(63.0, 63.0, 22.0)) ||    // item names
    util_eq(Color.rgb, util_color_to_vec(22.0, 27.0, 12.0))       // action bar bg
) {
    vertexColor = vec4(0.0);
}
if (
    util_eq(Color.rgb, util_color_to_vec(62.0, 42.0, 0.0)) ||     // smaller title
    util_eq(Color.rgb, util_color_to_vec(62.0, 21.0, 21.0))
) {
    Pos     = ProjMat * ModelViewMat * Pos;
    Pos.xy *= 0.75;
    Pos.y  += 0.05;
    gl_Position = Pos;
    return;
}
#elif !defined(IS_GRAYSCALE) && defined(FRAGMENT)
// normal font fragment
if (is_crosshair == 1) {
    if (color.a < 0.7) {
        vec2 uv = gl_FragCoord.xy / ScreenSize;

        float dx = abs(uv.x - 0.5) * ScreenSize.x;
        float dy = abs(uv.y - 0.5) * ScreenSize.y;

        if ((dx < 2.0) || (dy < 2.0)) {
            color = vec4(vec3(0.0), 0.7) * vertexColor * ColorModulator;
        }
    }
    color.a *= 0.7;
}
#elif defined(IS_GRAYSCALE) && defined(VERTEX)
// TTF font vertex
is_crosshair = 0;
// solid colors
if (
    util_eq(Color.rgb, util_color_to_vec(228.0, 247.0, 126.0)) || // slot text normal
    util_eq(Color.rgb, util_color_to_vec(228.0, 250.0, 126.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 255.0, 126.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 242.0, 126.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 238.0, 126.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 232.0, 126.0))
) {
    vertexColor.rgb = cs_txt_color_slots(false, false, Color.rgb);

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 2.0 / scale;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 1.31;
            Pos.y += ScreenSize.y / 28.0;
            break;
        case 2:
            Pos.x -= ScreenSize.x / 7.59;
            Pos.y += ScreenSize.y / 56.0;
            break;
        case 3:
            Pos.x -= ScreenSize.x / 31.0;
            Pos.y += ScreenSize.y / 84.0;
            break;
        case 4:
            Pos.x -= ScreenSize.x / 300.0;
            Pos.y += ScreenSize.y / 112.0;
            break;
    }

    Pos.x -= 9.0;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(228.0, 247.0, 128.0)) || // slot text big
    util_eq(Color.rgb, util_color_to_vec(228.0, 250.0, 128.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 255.0, 128.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 242.0, 128.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 238.0, 128.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 232.0, 128.0))
) {
    vertexColor.rgb = cs_txt_color_slots(true, false, Color.rgb);

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 2.0 / scale;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 1.31;
            Pos.y += ScreenSize.y / 28.0 + (20.0 / scale);
            break;
        case 2:
            Pos.x -= ScreenSize.x / 7.59;
            Pos.y += ScreenSize.y / 56.0 + (20.0 / scale);
            break;
        case 3:
            Pos.x -= ScreenSize.x / 31.0;
            Pos.y += ScreenSize.y / 84.0 + (20.0 / scale);
            break;
        case 4:
            Pos.x -= ScreenSize.x / 300.0;
            Pos.y += ScreenSize.y / 112.0 + (20.0 / scale);
            break;
    }

    Pos.x -= 7.0;
    Pos.y += 8.0;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(255.0, 168.0, 0.0)) ||   // action bar normal
    util_eq(Color.rgb, util_color_to_vec(255.0, 164.0, 0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(255.0, 162.0, 0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(255.0, 158.0, 0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(255.0, 152.0, 0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(255.0, 148.0, 0.0))
) {
    vertexColor.rgb = cs_txt_color_action(false, false, Color.rgb);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(128.0, 88.0,  0.0)) ||   // action bar dark
    util_eq(Color.rgb, util_color_to_vec(128.0, 84.0,  0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(128.0, 81.0,  0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(128.0, 78.0,  0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(128.0, 72.0,  0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(128.0, 68.0,  0.0))
) {
    vertexColor.rgb = cs_txt_color_action(true, false, Color.rgb);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(255.0, 86.0, 80.0))      // action bar red
) {
    vertexColor.rgb = util_color_to_vec(255.0, 20.0, 20.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(128.0, 41.0, 40.0))      // action bar dark red
) {
    vertexColor.rgb = util_color_to_vec(127.0, 10.0, 10.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(255.0, 255.0, 250.0)) || // action bar only shadow
    util_eq(Color.rgb, util_color_to_vec(255.0, 255.0, 240.0))
) {
    vertexColor = vec4(0.0);
}
// shadow colors
if (
    util_eq(Color.rgb, util_color_to_vec(57.0,  61.0,  31.0)) ||  // slot text normal
    util_eq(Color.rgb, util_color_to_vec(57.0,  62.0,  31.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  63.0,  31.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  60.0,  31.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  59.0,  31.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  58.0,  31.0))
) {
    vertexColor.rgb = cs_txt_color_slots(false, true, Color.rgb);

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 2.0 / scale;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 1.31;
            Pos.y += ScreenSize.y / 28.0;
            break;
        case 2:
            Pos.x -= ScreenSize.x / 7.59;
            Pos.y += ScreenSize.y / 56.0;
            break;
        case 3:
            Pos.x -= ScreenSize.x / 31.0;
            Pos.y += ScreenSize.y / 84.0;
            break;
        case 4:
            Pos.x -= ScreenSize.x / 300.0;
            Pos.y += ScreenSize.y / 112.0;
            break;
    }

    Pos.x -= 9.0;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(57.0,  61.0,  32.0)) ||  // slot text big
    util_eq(Color.rgb, util_color_to_vec(57.0,  62.0,  32.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  63.0,  32.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  60.0,  32.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  59.0,  32.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  58.0,  32.0))
) {
    vertexColor.rgb = cs_txt_color_slots(true, true, Color.rgb);

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 2.0 / scale;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 1.31;
            Pos.y += ScreenSize.y / 28.0 + (20.0 / scale);
            break;
        case 2:
            Pos.x -= ScreenSize.x / 7.59;
            Pos.y += ScreenSize.y / 56.0 + (20.0 / scale);
            break;
        case 3:
            Pos.x -= ScreenSize.x / 31.0;
            Pos.y += ScreenSize.y / 84.0 + (20.0 / scale);
            break;
        case 4:
            Pos.x -= ScreenSize.x / 300.0;
            Pos.y += ScreenSize.y / 112.0 + (20.0 / scale);
            break;
    }

    Pos.x -= 7.0;
    Pos.y += 8.0;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(63.0,  42.0,  0.0)) ||   // action bar normal gray
    util_eq(Color.rgb, util_color_to_vec(63.0,  41.0,  0.0)) ||   // action bar normal red
    util_eq(Color.rgb, util_color_to_vec(63.0,  40.0,  0.0)) ||   // action bar normal lime
    util_eq(Color.rgb, util_color_to_vec(63.0,  39.0,  0.0)) ||   // action bar normal aqua
    util_eq(Color.rgb, util_color_to_vec(63.0,  38.0,  0.0)) ||   // action bar normal gold
    util_eq(Color.rgb, util_color_to_vec(63.0,  37.0,  0.0))      // action bar normal purple
) {
    vertexColor.rgb = cs_txt_color_action(false, true, Color.rgb);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(32.0,  22.0,  0.0)) ||   // action bar dark gray
    util_eq(Color.rgb, util_color_to_vec(32.0,  21.0,  0.0)) ||   // action bar dark red
    util_eq(Color.rgb, util_color_to_vec(32.0,  20.0,  0.0)) ||   // action bar dark lime
    util_eq(Color.rgb, util_color_to_vec(32.0,  19.0,  0.0)) ||   // action bar dark aqua
    util_eq(Color.rgb, util_color_to_vec(32.0,  18.0,  0.0)) ||   // action bar dark gold
    util_eq(Color.rgb, util_color_to_vec(32.0,  17.0,  0.0))      // action bar dark purple
) {
    vertexColor.rgb = cs_txt_color_action(true, true, Color.rgb);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(63.0, 21.0, 20.0))       // action bar red
) {
    vertexColor.rgb = util_color_to_vec(63.0, 21.0, 20.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(32.0, 10.0, 10.0))       // action bar dark red
) {
    vertexColor.rgb = util_color_to_vec(32.0, 10.0, 10.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(63.0, 63.0, 62.0))       // action bar only shadow
) {
    vertexColor = vec4(0.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(63.0, 63.0, 60.0))
) {
    vertexColor = vec4(0.0);
    vec4 newPos = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    int scale = util_gui_scale(ProjMat, ScreenSize);
    
    newPos.x += util_gui_pixel(ProjMat).x * (12.0 / scale);

    gl_Position = newPos;
    return;
}
#elif defined(IS_GRAYSCALE) && defined(FRAGMENT)
// TTF font fragment
#endif
