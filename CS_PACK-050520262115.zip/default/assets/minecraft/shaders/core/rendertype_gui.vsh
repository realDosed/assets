#version 150

in vec3 Position;
in vec4 Color;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;

out vec4 vertexColor;

// CS_PACK
bool util_eq(vec3 a, vec3 b) {
    return length(a - b) < 0.002;
}
bool util_eq(vec4 a, vec4 b) {
    return length(a - b) < 0.002;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    vertexColor = Color;

    // CS_PACK
    // disable cooldown, chat bg and simillar stuff
    if (
        util_eq(Color, vec4(1.0, 1.0, 1.0, 0.5)) ||
        (util_eq(Color.rgb, vec3(0.0)) && Color.a <= 0.502)
    ) {
        vertexColor = vec4(0.0);
    }
}
