#ifdef VERTEX
// solid colors
if (
    util_eq(Color.rgb, util_color_to_vec(228.0, 247.0, 126.0)) || // slot text normal
    util_eq(Color.rgb, util_color_to_vec(228.0, 250.0, 126.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 255.0, 126.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 242.0, 126.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 238.0, 126.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 232.0, 126.0))
) {
    vertexColor.rgb = cs_txt_color_slots(false, false, Color.rgb);

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 2.0 / scale;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 1.31;
            Pos.y += ScreenSize.y / 28.0;
            break;
        case 2:
            Pos.x -= ScreenSize.x / 7.59;
            Pos.y += ScreenSize.y / 56.0;
            break;
        case 3:
            Pos.x -= ScreenSize.x / 31.0;
            Pos.y += ScreenSize.y / 84.0;
            break;
        case 4:
            Pos.x -= ScreenSize.x / 300.0;
            Pos.y += ScreenSize.y / 112.0;
            break;
    }

    Pos.x -= 9.0;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(228.0, 247.0, 128.0)) || // slot text big
    util_eq(Color.rgb, util_color_to_vec(228.0, 250.0, 128.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 255.0, 128.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 242.0, 128.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 238.0, 128.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 232.0, 128.0))
) {
    vertexColor.rgb = cs_txt_color_slots(true, false, Color.rgb);

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 2.0 / scale;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 1.31;
            Pos.y += ScreenSize.y / 28.0 + (20.0 / scale);
            break;
        case 2:
            Pos.x -= ScreenSize.x / 7.59;
            Pos.y += ScreenSize.y / 56.0 + (20.0 / scale);
            break;
        case 3:
            Pos.x -= ScreenSize.x / 31.0;
            Pos.y += ScreenSize.y / 84.0 + (20.0 / scale);
            break;
        case 4:
            Pos.x -= ScreenSize.x / 300.0;
            Pos.y += ScreenSize.y / 112.0 + (20.0 / scale);
            break;
    }

    Pos.x -= 7.0;
    Pos.y += 8.0;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(255.0, 168.0, 0.0)) ||   // action bar normal
    util_eq(Color.rgb, util_color_to_vec(255.0, 164.0, 0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(255.0, 162.0, 0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(255.0, 158.0, 0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(255.0, 152.0, 0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(255.0, 148.0, 0.0))
) {
    vertexColor.rgb = cs_txt_color_action(false, false, Color.rgb);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(128.0, 88.0,  0.0)) ||   // action bar dark
    util_eq(Color.rgb, util_color_to_vec(128.0, 84.0,  0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(128.0, 81.0,  0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(128.0, 78.0,  0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(128.0, 72.0,  0.0)) ||
    util_eq(Color.rgb, util_color_to_vec(128.0, 68.0,  0.0))
) {
    vertexColor.rgb = cs_txt_color_action(true, false, Color.rgb);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(255.0, 86.0, 80.0))      // action bar red
) {
    vertexColor.rgb = util_color_to_vec(255.0, 20.0, 20.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(128.0, 41.0, 40.0))      // action bar dark red
) {
    vertexColor.rgb = util_color_to_vec(127.0, 10.0, 10.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(255.0, 255.0, 250.0)) || // action bar only shadow
    util_eq(Color.rgb, util_color_to_vec(255.0, 255.0, 240.0))
) {
    vertexColor = vec4(0.0);
}
// shadow colors
if (
    util_eq(Color.rgb, util_color_to_vec(57.0,  61.0,  31.0)) ||  // slot text normal
    util_eq(Color.rgb, util_color_to_vec(57.0,  62.0,  31.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  63.0,  31.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  60.0,  31.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  59.0,  31.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  58.0,  31.0))
) {
    vertexColor.rgb = cs_txt_color_slots(false, true, Color.rgb);

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 2.0 / scale;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 1.31;
            Pos.y += ScreenSize.y / 28.0;
            break;
        case 2:
            Pos.x -= ScreenSize.x / 7.59;
            Pos.y += ScreenSize.y / 56.0;
            break;
        case 3:
            Pos.x -= ScreenSize.x / 31.0;
            Pos.y += ScreenSize.y / 84.0;
            break;
        case 4:
            Pos.x -= ScreenSize.x / 300.0;
            Pos.y += ScreenSize.y / 112.0;
            break;
    }

    Pos.x -= 9.0;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(57.0,  61.0,  32.0)) ||  // slot text big
    util_eq(Color.rgb, util_color_to_vec(57.0,  62.0,  32.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  63.0,  32.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  60.0,  32.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  59.0,  32.0)) ||
    util_eq(Color.rgb, util_color_to_vec(57.0,  58.0,  32.0))
) {
    vertexColor.rgb = cs_txt_color_slots(true, true, Color.rgb);

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 2.0 / scale;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 1.31;
            Pos.y += ScreenSize.y / 28.0 + (20.0 / scale);
            break;
        case 2:
            Pos.x -= ScreenSize.x / 7.59;
            Pos.y += ScreenSize.y / 56.0 + (20.0 / scale);
            break;
        case 3:
            Pos.x -= ScreenSize.x / 31.0;
            Pos.y += ScreenSize.y / 84.0 + (20.0 / scale);
            break;
        case 4:
            Pos.x -= ScreenSize.x / 300.0;
            Pos.y += ScreenSize.y / 112.0 + (20.0 / scale);
            break;
    }

    Pos.x -= 7.0;
    Pos.y += 8.0;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(63.0,  42.0,  0.0)) ||   // action bar normal gray
    util_eq(Color.rgb, util_color_to_vec(63.0,  41.0,  0.0)) ||   // action bar normal red
    util_eq(Color.rgb, util_color_to_vec(63.0,  40.0,  0.0)) ||   // action bar normal lime
    util_eq(Color.rgb, util_color_to_vec(63.0,  39.0,  0.0)) ||   // action bar normal aqua
    util_eq(Color.rgb, util_color_to_vec(63.0,  38.0,  0.0)) ||   // action bar normal gold
    util_eq(Color.rgb, util_color_to_vec(63.0,  37.0,  0.0))      // action bar normal purple
) {
    vertexColor.rgb = cs_txt_color_action(false, true, Color.rgb);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(32.0,  22.0,  0.0)) ||   // action bar dark gray
    util_eq(Color.rgb, util_color_to_vec(32.0,  21.0,  0.0)) ||   // action bar dark red
    util_eq(Color.rgb, util_color_to_vec(32.0,  20.0,  0.0)) ||   // action bar dark lime
    util_eq(Color.rgb, util_color_to_vec(32.0,  19.0,  0.0)) ||   // action bar dark aqua
    util_eq(Color.rgb, util_color_to_vec(32.0,  18.0,  0.0)) ||   // action bar dark gold
    util_eq(Color.rgb, util_color_to_vec(32.0,  17.0,  0.0))      // action bar dark purple
) {
    vertexColor.rgb = cs_txt_color_action(true, true, Color.rgb);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(63.0, 21.0, 20.0))       // action bar red
) {
    vertexColor.rgb = util_color_to_vec(63.0, 21.0, 20.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(32.0, 10.0, 10.0))       // action bar dark red
) {
    vertexColor.rgb = util_color_to_vec(32.0, 10.0, 10.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(63.0, 63.0, 62.0))       // action bar only shadow
) {
    vertexColor = vec4(0.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(63.0, 63.0, 60.0))
) {
    vertexColor = vec4(0.0);
    vec4 newPos = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    int scale = util_gui_scale(ProjMat, ScreenSize);
    
    newPos.x += util_gui_pixel(ProjMat).x * (12.0 / scale);

    gl_Position = newPos;
    return;
}
#endif
#ifdef FRAGMENT
#endif
