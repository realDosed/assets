#ifdef VERTEX
is_crosshair = 0;
// solid colors
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 20.0))       // full quad white
) {
    vertexColor.rgb = vec3(1.0);
    gl_Position = cs_full_quad(ProjMat, ModelViewMat, Pos, -0.1);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(75.0, 80.0, 20.0))       // full quad black
) {
    is_crosshair = 1;
    vertexColor.rgb = vec3(0.0);
    gl_Position = cs_full_quad(ProjMat, ModelViewMat, Pos, 0.0);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(80.0, 80.0, 20.0))       // full quad red
) {
    vertexColor = vec4(1.0, 0.0, 0.0, clamp(vertexColor.a, 0.0, 0.12));
    gl_Position = cs_full_quad(ProjMat, ModelViewMat, Pos, 0.0);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(85.0, 80.0, 20.0))       // full quad white transp
) {
    vertexColor = vec4(vec3(1.0), clamp(vertexColor.a, 0.0, 0.12));
    gl_Position = cs_full_quad(ProjMat, ModelViewMat, Pos, 0.0);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 40.0))       // crosshair gray
) {
    vertexColor.rgb = util_color_to_vec(170.0, 170.0, 170.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 42.0))       // crosshair red
) {
    vertexColor.rgb = util_color_to_vec(255.0, 85.0, 85.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 44.0))       // crosshair lime
) {
    vertexColor.rgb = util_color_to_vec(85.0, 255.0, 85.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 46.0))       // crosshair aqua
) {
    vertexColor.rgb = util_color_to_vec(85.0, 255.0, 255.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 48.0))       // crosshair gold
) {
    vertexColor.rgb = util_color_to_vec(255.0, 170.0, 0.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(70.0, 80.0, 50.0))       // crosshair purple
) {
    vertexColor.rgb = util_color_to_vec(255.0, 85.0, 255.0);
    gl_Position = cs_txt_move_crosshair(ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(228.0, 247.0, 124.0)) || // slots normal
    util_eq(Color.rgb, util_color_to_vec(228.0, 250.0, 124.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 255.0, 124.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 242.0, 124.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 238.0, 124.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 232.0, 124.0))
) {
    vertexColor.rgb = cs_txt_color_slots(false, Color.rgb);

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 4.0 / scale;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 0.5672;
            Pos.y += ScreenSize.y / 28.0 - 44.0 / scale;
            break;
        case 2:
            Pos.x -= ScreenSize.x / 2.622;
            Pos.y += ScreenSize.y / 56.0 - 44.0 / scale;
            break;
        case 3:
            Pos.x -= ScreenSize.x / 6.98;
            Pos.y += ScreenSize.y / 84.0 - 44.0 / scale;
            break;
        case 4:
            Pos.x -= ScreenSize.x / 15.2;
            Pos.y += ScreenSize.y / 112.0 - 44.0 / scale;
            break;
    }

    Pos.x += 29.0;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(228.0, 247.0, 122.0)) || // slots big
    util_eq(Color.rgb, util_color_to_vec(228.0, 250.0, 122.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 255.0, 122.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 242.0, 122.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 238.0, 122.0)) ||
    util_eq(Color.rgb, util_color_to_vec(228.0, 232.0, 122.0))
) {
    vertexColor.rgb = cs_txt_color_slots(true, Color.rgb);

    float f = 1.5;

    int scale = util_gui_scale(ProjMat, ScreenSize);
    Pos.xy *= 4.0 / scale * f;

    switch (scale) {
        case 1:
            Pos.x -= ScreenSize.x / 0.5672 * f + (112.0 / scale);
            Pos.y += ScreenSize.y / 28.0 - (50.0 / scale) * f;
            break;
        case 2:
            Pos.x -= ScreenSize.x / 2.622 * f + (113.0 / scale);
            Pos.y += ScreenSize.y / 56.0 - (50.0 / scale) * f;
            break;
        case 3:
            Pos.x -= ScreenSize.x / 6.98 * f + (112.0 / scale);
            Pos.y += ScreenSize.y / 84.0 - (50.0 / scale) * f;
            break;
        case 4:
            Pos.x -= ScreenSize.x / 15.2 * f + (112.0 / scale);
            Pos.y += ScreenSize.y / 112.0 - (50.0 / scale) * f;
            break;
    }

    Pos.x += 50.0;
    Pos.y += 4.5;

    gl_Position = ProjMat * ModelViewMat * Pos;
    return;
}
if (
	util_eq(Color.rgb, util_color_to_vec(255.0, 255.0, 90.0))     // item names + inv char
) {
    vertexColor = vec4(0.0);
}
if (
    util_eq(Color.rgb, util_color_to_vec(250.0, 170.0, 0.0)) ||   // smaller title
    util_eq(Color.rgb, util_color_to_vec(250.0, 85.0, 85.0))
) {
    Pos     = ProjMat * ModelViewMat * Pos;
    Pos.xy *= 0.75;
    Pos.y  += 0.05;
    gl_Position = Pos;
    return;
}
if (
    util_eq(Color.rgb, util_color_to_vec(90.0, 110.0, 50.0))      // action bar bg
) {
    vertexColor.rgb = vec3(1.0);
    gl_Position = cs_txt_move_action(false, ProjMat, ModelViewMat, Pos, ScreenSize);
    return;
}
// shadow colors
if (
    util_eq(Color.rgb, util_color_to_vec(17.0, 20.0,  5.0)) ||    // full quad white
    util_eq(Color.rgb, util_color_to_vec(18.0, 20.0,  5.0)) ||    // full quad black
    util_eq(Color.rgb, util_color_to_vec(20.0, 20.0,  5.0)) ||    // full quad red
    util_eq(Color.rgb, util_color_to_vec(21.0, 20.0,  5.0)) ||    // full quad white transp
    util_eq(Color.rgb, util_color_to_vec(17.0, 20.0, 10.0)) ||    // crosshair gray + red
    util_eq(Color.rgb, util_color_to_vec(17.0, 20.0, 11.0)) ||    // crosshair lime + aqua
    util_eq(Color.rgb, util_color_to_vec(17.0, 20.0, 12.0)) ||    // crosshair gold + purple
    util_eq(Color.rgb, util_color_to_vec(57.0, 61.0, 31.0)) ||    // slots normal gray
    util_eq(Color.rgb, util_color_to_vec(57.0, 62.0, 31.0)) ||    // slots normal red
    util_eq(Color.rgb, util_color_to_vec(57.0, 63.0, 31.0)) ||    // slots normal lime
    util_eq(Color.rgb, util_color_to_vec(57.0, 60.0, 31.0)) ||    // slots normal aqua
    util_eq(Color.rgb, util_color_to_vec(57.0, 59.0, 31.0)) ||    // slots normal gold
    util_eq(Color.rgb, util_color_to_vec(57.0, 58.0, 31.0)) ||    // slots normal purple
    util_eq(Color.rgb, util_color_to_vec(57.0, 61.0, 30.0)) ||    // slots big gray
    util_eq(Color.rgb, util_color_to_vec(57.0, 62.0, 30.0)) ||    // slots big red
    util_eq(Color.rgb, util_color_to_vec(57.0, 63.0, 30.0)) ||    // slots big lime
    util_eq(Color.rgb, util_color_to_vec(57.0, 60.0, 30.0)) ||    // slots big aqua
    util_eq(Color.rgb, util_color_to_vec(57.0, 59.0, 30.0)) ||    // slots big gold
    util_eq(Color.rgb, util_color_to_vec(57.0, 58.0, 30.0)) ||    // slots big purple
    util_eq(Color.rgb, util_color_to_vec(63.0, 63.0, 22.0)) ||    // item names
    util_eq(Color.rgb, util_color_to_vec(22.0, 27.0, 12.0))       // action bar bg
) {
    vertexColor = vec4(0.0);
}
if (
    util_eq(Color.rgb, util_color_to_vec(62.0, 42.0, 0.0)) ||     // smaller title
    util_eq(Color.rgb, util_color_to_vec(62.0, 21.0, 21.0))
) {
    Pos     = ProjMat * ModelViewMat * Pos;
    Pos.xy *= 0.75;
    Pos.y  += 0.05;
    gl_Position = Pos;
    return;
}
#endif
#ifdef FRAGMENT
if (is_crosshair == 1) {
    if (color.a < 0.7) {
        vec2 uv = gl_FragCoord.xy / ScreenSize;

        float dx = abs(uv.x - 0.5) * ScreenSize.x;
        float dy = abs(uv.y - 0.5) * ScreenSize.y;

        if ((dx < 2.0) || (dy < 2.0)) {
            color = vec4(vec3(0.0), 0.7) * vertexColor * ColorModulator;
        }
    }
    color.a *= 0.7;
}
#endif
