vec3 cs_txt_color_slots(bool is_big, vec3 color) {
    if (!is_big) {
        if (util_eq(color, util_color_to_vec(228.0, 247.0, 124.0))) return util_color_to_vec(170.0, 170.0, 170.0); // gray
        if (util_eq(color, util_color_to_vec(228.0, 250.0, 124.0))) return util_color_to_vec(255.0,  85.0,  85.0); // red
        if (util_eq(color, util_color_to_vec(228.0, 255.0, 124.0))) return util_color_to_vec( 85.0, 255.0,  85.0); // lime
        if (util_eq(color, util_color_to_vec(228.0, 242.0, 124.0))) return util_color_to_vec( 85.0, 255.0, 255.0); // aqua
        if (util_eq(color, util_color_to_vec(228.0, 238.0, 124.0))) return util_color_to_vec(255.0, 170.0,   0.0); // gold
        if (util_eq(color, util_color_to_vec(228.0, 232.0, 124.0))) return util_color_to_vec(255.0,  85.0, 255.0); // purple
        return vec3(1.0);
    } else {
        if (util_eq(color, util_color_to_vec(228.0, 247.0, 122.0))) return util_color_to_vec(170.0, 170.0, 170.0); // gray
        if (util_eq(color, util_color_to_vec(228.0, 250.0, 122.0))) return util_color_to_vec(255.0,  85.0,  85.0); // red
        if (util_eq(color, util_color_to_vec(228.0, 255.0, 122.0))) return util_color_to_vec( 85.0, 255.0,  85.0); // lime
        if (util_eq(color, util_color_to_vec(228.0, 242.0, 122.0))) return util_color_to_vec( 85.0, 255.0, 255.0); // aqua
        if (util_eq(color, util_color_to_vec(228.0, 238.0, 122.0))) return util_color_to_vec(255.0, 170.0,   0.0); // gold
        if (util_eq(color, util_color_to_vec(228.0, 232.0, 122.0))) return util_color_to_vec(255.0,  85.0, 255.0); // purple
        return vec3(1.0);
    }
}
vec4 cs_txt_move_crosshair(mat4 projmat, mat4 modelviewmat, vec4 pos, vec2 screen_size) {
    int scale = util_gui_scale(projmat, screen_size);
    vec2 pixel = util_gui_pixel(projmat);

    pos     = projmat * modelviewmat * pos;
    pos.xy *= 1.0 / scale;
    pos.x  -= (pixel.x * -0.5) * (4.0 / scale);
    pos.y  -= (pixel.y * 29.5) * (4.0 / scale);

    return pos;
}
vec4 cs_full_quad(mat4 projmat, mat4 modelviewmat, vec4 pos, float z_shift) {
    const vec2[4] corners = vec2[4](vec2(-1, 1), vec2(-1, -1), vec2(1, -1), vec2(1, 1));
    vec2 corner = corners[gl_VertexID % 4];

    pos     = projmat * modelviewmat * pos;
    pos.xy  = corner;
    pos.z  += z_shift;

    return pos;
}
