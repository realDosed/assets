#ifdef VERTEX
// emissive textures
vec4 tex_color0 = util_vertex_color(Sampler0, texCoord);
if (
    util_eq(tex_color0.rgb, vec3(160.0/255.0))                ||
    util_eq(tex_color0,     vec4(0.0, 0.0, 0.0, 180.0/255.0))
) {
    lightColor  = vec4(1.0);
    vertexColor = vec4(1.0);
}
#endif
#ifdef FRAGMENT
// emissive skyboxes
int alpha = int(baseColor.a * 255.0);
if (alpha == 250) {        
    fragColor   = baseColor;
    fragColor.a = 1.0;
    return;
}
#endif
