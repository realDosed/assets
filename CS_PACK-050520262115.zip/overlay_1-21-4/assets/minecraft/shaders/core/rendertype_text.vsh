#version 150

#moj_import <minecraft:fog.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

uniform mat4 ModelViewMat;
uniform mat4 ProjMat;
uniform int FogShape;
uniform vec2 ScreenSize;
uniform float GameTime;

out float vertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// CS_PACK
flat out int is_crosshair;
#moj_import <cs_utils.glsl>
#moj_import <cs_text_utils.glsl>
#moj_import <cs_text_intensity_utils.glsl>

void main() {
    vec4 Pos = vec4(Position, 1.0);

    vertexDistance = fog_distance(Position, FogShape);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;

    // CS_PACK
    #define VERTEX
    #moj_import <cs_text.glsl>

    gl_Position = ProjMat * ModelViewMat * Pos;
}
