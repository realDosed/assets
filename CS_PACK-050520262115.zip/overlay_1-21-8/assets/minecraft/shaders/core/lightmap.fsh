#version 150

layout(std140) uniform LightmapInfo {
    float AmbientLightFactor;
    float SkyFactor;
    float BlockFactor;
    int UseBrightLightmap;
    float NightVisionFactor;
    float DarknessScale;
    float DarkenWorldFactor;
    float BrightnessFactor;
    vec3 SkyLightColor;
} lightmapInfo;

in vec2 texCoord;

out vec4 fragColor;

float get_brightness(float light_level, float ambient) {
    float darkness = 1.0 - light_level;
    return (1.0 - darkness) / (darkness * 3.0 + 1.0) * (1.0 - ambient) + ambient;
}
vec3 notGamma(vec3 color) {
    float maxComponent = max(max(color.x, color.y), color.z);
    float maxInverted = 1.0f - maxComponent;
    float maxScaled = 1.0f - maxInverted * maxInverted * maxInverted;
    return color * (maxScaled / maxComponent);
}

void main() {
    float block_level = floor(texCoord.x * 16) / 15;
    float sky_level = floor(texCoord.y * 16) * lightmapInfo.SkyFactor / 15;

    float light_level = max(block_level, sky_level);
    light_level = clamp(light_level, 0.0, 1.0);

    float ambient = ((lightmapInfo.SkyLightColor.r + lightmapInfo.SkyLightColor.g + lightmapInfo.SkyLightColor.b) / 3 + 0.01) * lightmapInfo.AmbientLightFactor;

    vec3 color = vec3(get_brightness(light_level, max(ambient, 0.05)));

    color = mix(color, color * max(light_level, 0.4), lightmapInfo.DarkenWorldFactor);
    color -= vec3(lightmapInfo.DarknessScale);

    color = clamp(color, 0.0, 1.0);
    vec3 notGamma = notGamma(color);
    color = mix(color, notGamma, 0.25);

    if (lightmapInfo.NightVisionFactor > 0.0) {
        color = mix(color, vec3(0.65, 1.0, 0.65), lightmapInfo.NightVisionFactor);
    }

    if (lightmapInfo.BrightnessFactor > 1.0) {
        color *= lightmapInfo.BrightnessFactor;
    }

    color = clamp(color, 0.0, 1.0);
    fragColor = vec4(color, 1.0);
}
