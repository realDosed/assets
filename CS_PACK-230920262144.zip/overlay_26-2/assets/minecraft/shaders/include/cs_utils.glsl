#ifdef VULKAN
    #extension GL_KHR_shader_subgroup_basic : enable
    int VERTEX_ID = int(gl_SubgroupInvocationID) % 4;
#else
    #extension GL_ARB_shader_draw_parameters : enable
    #ifdef GL_ARB_shader_draw_parameters
    int VERTEX_ID = (gl_VertexID - gl_BaseVertexARB) % 4;
    #else
    int VERTEX_ID = gl_VertexID % 4;
    #endif
#endif

bool util_eq(float a, float b) {
    return abs(a - b) < 0.002;
}
bool util_eq(vec2 a, vec2 b) {
    return length(a - b) < 0.002;
}
bool util_eq(vec3 a, vec3 b) {
    return length(a - b) < 0.002;
}
bool util_eq(vec4 a, vec4 b) {
    return length(a - b) < 0.002;
}
vec3 util_color_to_vec(float r, float g, float b) {
    return vec3(r / 255.0, g / 255.0, b / 255.0);
}
vec4 util_color_to_vec(float r, float g, float b, float a) {
    return vec4(r / 255.0, g / 255.0, b / 255.0, a / 255.0);
}
vec4 util_vertex_color(sampler2D Sampler, vec2 coords) {
    ivec2 tex_size = textureSize(Sampler, 0);
    float pix_x = (1.0 / tex_size.x) * 0.498;
    float pix_y = (1.0 / tex_size.y) * 0.498;
    int vertexID = VERTEX_ID;
    vec2 offset = vec2(0.0);
    switch(vertexID) {
        case 0:  offset = vec2(-pix_x, -pix_y); break;
        case 1:  offset = vec2(-pix_x,  pix_y); break;
        case 2:  offset = vec2( pix_x,  pix_y); break;
        case 3:  offset = vec2( pix_x, -pix_y); break;
        default: offset = vec2(0.0);            break;
    }
    return texture(Sampler, coords - offset);
}
vec2 util_gui_pixel(mat4 projmat) {
    return vec2(projmat[0][0], projmat[1][1]) / 2.0;
}
int util_gui_scale(mat4 projmat, vec2 screen_size) {
    return int(round(screen_size.x * projmat[0][0] / 2.0));
}
